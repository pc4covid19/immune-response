# Perform timing tests

